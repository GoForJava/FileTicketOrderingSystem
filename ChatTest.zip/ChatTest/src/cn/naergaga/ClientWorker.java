package cn.naergaga;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Created by mei on 2017/1/23.
 */
public class ClientWorker implements Runnable {
    private Socket socket = null;

    public ClientWorker(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            Scanner sc = new Scanner(System.in);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            String line =null;
            while (sc.hasNext()) {
                line = sc.nextLine();
                writer.write(line);
                writer.newLine();
                writer.flush();
                if (line.equals("over")) {
                    break;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
