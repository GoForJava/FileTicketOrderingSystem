package cn.naergaga;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by mei on 2017/1/23.
 */
public class ServerMain {

    public static void main(String[] args){
        try {
            ServerSocket socket = new ServerSocket(12345);
            Socket s1 = null;
            while ((s1=socket.accept())!=null) {
                ServerWorker server = new ServerWorker(s1);
                Thread t1 = new Thread(server);
                t1.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
