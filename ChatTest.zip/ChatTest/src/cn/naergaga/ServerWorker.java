package cn.naergaga;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Created by mei on 2017/1/23.
 */
public class ServerWorker implements Runnable {
    private Socket _socket = null;

    public ServerWorker(Socket socket) {
        this._socket = socket;
    }

    @Override
    public void run() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(_socket.getInputStream()));
            PrintWriter pw = new PrintWriter(_socket.getOutputStream(),true);
            String line = null;
            while ((line=reader.readLine())!=null){
                System.out.println(line);
                pw.println(line.toUpperCase());
                if (line.endsWith("over")) {
                    break;
                }
            }

            pw.close();
            reader.close();
            _socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
