package 网络编程;

import java.net.*;
import java.io.*;

public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {
		
		Socket socket = new Socket("127.0.0.1",4353);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		while(true) {
			String line = br.readLine();
			bw.write(line);
			bw.newLine();
			bw.flush();
			if(line.equals("over")) {
				break;
			}
			System.out.println(reader.readLine());
			
		}
		reader.close();
		bw.close();
		br.close();
		socket.close();
	}

}
