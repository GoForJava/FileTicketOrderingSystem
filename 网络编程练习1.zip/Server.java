package 网络编程;

import java.io.*;
import java.net.*;
public class Server {
	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = new ServerSocket(4353);
		Socket socket = serverSocket.accept();
		System.out.println(socket.getInetAddress().getHostAddress()+"is on line");
		BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		String line = null;
		while((line = br.readLine()) != null) {
			if(line.equals("over")) {
				break;
			}
			System.out.println(line);
			bw.write(line.toUpperCase());
			bw.newLine();
			bw.flush();
			
		}
		bw.close();
		br.close();
		socket.close();
		System.out.println(socket.getInetAddress().getHostAddress()+"is out of line");
	}
}
